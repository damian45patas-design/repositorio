# YTM Client — compilar el APK con GitHub Actions

1. Descomprime este ZIP.
2. Entra a https://github.com, crea una cuenta y pulsa "New repository" (puede ser privado). Ponle un nombre, por ejemplo `ytm-client`.
3. En el repositorio nuevo pulsa "uploading an existing file" y arrastra TODO el contenido de la carpeta descomprimida
   (incluida la carpeta oculta `.github`). Pulsa "Commit changes".
   - Si `.github` no se subió: Add file > Create new file, escribe el nombre `.github/workflows/build.yml`
     y pega el contenido de `WORKFLOW_build.yml`.
4. Ve a la pestaña "Actions". Si pide activar los workflows, acéptalo. Entra a "Build APK" > "Run workflow".
5. Espera ~10 minutos. Al terminar, abre la ejecución y baja el archivo "ytm-client-apk" (sección Artifacts).
6. Descomprímelo: dentro está `app-release.apk`. Pásalo al celular e instálalo
   (Android te pedirá permitir "instalar apps de orígenes desconocidos").

Si la compilación falla (X roja), abre la ejecución, copia el error de la línea roja y pásaselo a Claude.
