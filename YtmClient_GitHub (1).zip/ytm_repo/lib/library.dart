import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'globals.dart';
import 'models.dart';
import 'yt.dart';

/// Historial, playlists propias y descargas (todo guardado en un JSON local).
class Library extends ChangeNotifier {
  late Directory _dir;
  late File _db;

  final List<Song> history = [];
  final List<UserPlaylist> playlists = [];
  final List<Song> downloads = [];
  final Map<String, String> files = {}; // id -> nombre de archivo
  final Map<String, double> progress = {}; // descargas en curso
  final Set<String> downloadingPlaylists = {};

  Future<void> load() async {
    _dir = await getApplicationSupportDirectory();
    await Directory('${_dir.path}/audio').create(recursive: true);
    _db = File('${_dir.path}/library.json');
    if (await _db.exists()) {
      try {
        final j = jsonDecode(await _db.readAsString()) as Map<String, dynamic>;
        List<Song> songs(String k) => ((j[k] as List?) ?? [])
            .map((e) => Song.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        history.addAll(songs('history'));
        downloads.addAll(songs('downloads'));
        playlists.addAll(((j['playlists'] as List?) ?? [])
            .map((e) => UserPlaylist.fromJson(Map<String, dynamic>.from(e as Map))));
        files.addAll(Map<String, String>.from((j['files'] as Map?) ?? {}));
      } catch (_) {}
    }
  }

  void _save() {
    _db.writeAsStringSync(jsonEncode({
      'history': history.map((s) => s.toJson()).toList(),
      'downloads': downloads.map((s) => s.toJson()).toList(),
      'playlists': playlists.map((p) => p.toJson()).toList(),
      'files': files,
    }));
    notifyListeners();
  }

  // ---------- historial ----------
  void addHistory(Song s) {
    history.remove(s);
    history.insert(0, s);
    if (history.length > 200) history.removeRange(200, history.length);
    _save();
  }

  // ---------- playlists ----------
  UserPlaylist createPlaylist(String name) {
    final existing = playlists.where((p) => p.name == name);
    if (existing.isNotEmpty) return existing.first;
    final p = UserPlaylist(name);
    playlists.add(p);
    _save();
    return p;
  }

  void deletePlaylist(UserPlaylist p) {
    playlists.remove(p);
    _save();
  }

  void addToPlaylist(UserPlaylist p, Song s) {
    if (!p.songs.contains(s)) p.songs.add(s);
    _save();
  }

  void removeFromPlaylist(UserPlaylist p, Song s) {
    p.songs.remove(s);
    _save();
  }

  // ---------- descargas ----------
  bool isDownloaded(String id) => localUri(id) != null;

  Uri? localUri(String id) {
    final n = files[id];
    if (n == null) return null;
    final f = File('${_dir.path}/audio/$n');
    return f.existsSync() ? Uri.file(f.path) : null;
  }

  int downloadedCount(UserPlaylist p) => p.songs.where((s) => isDownloaded(s.id)).length;

  Future<void> download(Song s) async {
    if (isDownloaded(s.id) || progress.containsKey(s.id)) return;
    progress[s.id] = 0;
    notifyListeners();
    try {
      final info = await Yt.bestAudio(s.id);
      final name = '${s.id}.${info.container.name}';
      final tmp = File('${_dir.path}/audio/$name.part');
      final sink = tmp.openWrite();
      final total = info.size.totalBytes;
      var got = 0;
      var last = 0.0;
      await for (final chunk in Yt.yt.videos.streams.get(info)) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0 && got / total - last >= 0.02) {
          last = got / total;
          progress[s.id] = last;
          notifyListeners();
        }
      }
      await sink.close();
      await tmp.rename('${_dir.path}/audio/$name');
      files[s.id] = name;
      if (!downloads.contains(s)) downloads.insert(0, s);
      _save();
    } catch (_) {
      showToast('No se pudo descargar "${s.title}"');
    } finally {
      progress.remove(s.id);
      notifyListeners();
    }
  }

  Future<void> downloadPlaylist(UserPlaylist p) async {
    if (!downloadingPlaylists.add(p.name)) return;
    notifyListeners();
    for (final s in List.of(p.songs)) {
      await download(s);
    }
    downloadingPlaylists.remove(p.name);
    notifyListeners();
  }

  Future<void> deleteDownload(Song s) async {
    final n = files.remove(s.id);
    if (n != null) {
      final f = File('${_dir.path}/audio/$n');
      if (await f.exists()) await f.delete();
    }
    downloads.remove(s);
    _save();
  }
}
