import 'package:flutter/foundation.dart';
import 'handler.dart';
import 'library.dart';

late Library lib;
late MusicHandler audio;

final toast = ValueNotifier<String?>(null);
void showToast(String m) {
  toast.value = null;
  toast.value = m;
}
