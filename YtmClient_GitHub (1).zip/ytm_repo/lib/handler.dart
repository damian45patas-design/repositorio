import 'dart:async';
import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'globals.dart';
import 'library.dart';
import 'models.dart';
import 'yt.dart';

/// Motor de reproducción: cola propia, radio infinita, segundo plano y controles del sistema.
/// En Android/iOS/macOS se registra con audio_service (notificación, pantalla de bloqueo);
/// en Windows/Linux se usa directamente.
class MusicHandler extends BaseAudioHandler with SeekHandler {
  MusicHandler(this.lib) {
    player.playbackEventStream.listen((_) => _broadcast(), onError: (Object e, StackTrace s) {});
    player.processingStateStream.listen((s) {
      if (s == ProcessingState.completed) skipToNext();
    });
    player.durationStream.listen((d) {
      final m = mediaItem.value;
      if (m != null && d != null) mediaItem.add(m.copyWith(duration: d));
    });
    eq?.setEnabled(true);
  }

  final Library lib;

  /// Ecualizador: solo disponible en Android.
  final AndroidEqualizer? eq = Platform.isAndroid ? AndroidEqualizer() : null;

  late final AudioPlayer player = AudioPlayer(
    audioPipeline: AudioPipeline(androidAudioEffects: [if (eq != null) eq!]),
  );

  final currentSong = ValueNotifier<Song?>(null);
  final infinite = ValueNotifier<bool>(true);

  final List<Song> _queue = [];
  int _index = -1;
  int _token = 0;
  int _fails = 0;
  bool _extending = false;

  void _broadcast() {
    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        player.playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
      ],
      systemActions: const {MediaAction.seek, MediaAction.seekForward, MediaAction.seekBackward},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: const {
        ProcessingState.idle: AudioProcessingState.idle,
        ProcessingState.loading: AudioProcessingState.loading,
        ProcessingState.buffering: AudioProcessingState.buffering,
        ProcessingState.ready: AudioProcessingState.ready,
        ProcessingState.completed: AudioProcessingState.completed,
      }[player.processingState]!,
      playing: player.playing,
      updatePosition: player.position,
      bufferedPosition: player.bufferedPosition,
      speed: player.speed,
      queueIndex: _index,
    ));
  }

  Future<void> playQueue(List<Song> songs, int index) async {
    _queue
      ..clear()
      ..addAll(songs);
    _fails = 0;
    await _playIndex(index);
  }

  Future<void> enqueue(Song s) async {
    if (_queue.isEmpty || _index < 0) {
      await playQueue([s], 0);
    } else {
      _queue.add(s);
      showToast('Añadida a la cola');
    }
  }

  Future<void> _playIndex(int i) async {
    if (i < 0 || i >= _queue.length) return;
    _index = i;
    final s = _queue[i];
    final token = ++_token;
    currentSong.value = s;
    mediaItem.add(MediaItem(
      id: s.id,
      title: s.title,
      artist: s.artist,
      artUri: s.thumb.isEmpty ? null : Uri.parse(s.thumb),
    ));
    try {
      final uri = lib.localUri(s.id) ?? await Yt.audioUrl(s.id);
      if (token != _token) return;
      await player.setAudioSource(AudioSource.uri(uri));
      if (token != _token) return;
      _fails = 0;
      lib.addHistory(s);
      player.play(); // no se espera: el Future termina cuando acaba la canción
    } catch (e) {
      if (token != _token) return;
      showToast('No se pudo reproducir "${s.title}"');
      if (++_fails < 3) await skipToNext();
      return;
    }
    if (infinite.value && _index >= _queue.length - 2) unawaited(_extendQueue());
  }

  /// Reproducción infinita: agrega canciones relacionadas al final de la cola.
  Future<void> _extendQueue() async {
    if (_extending || _queue.isEmpty) return;
    _extending = true;
    try {
      final more = await Yt.related(_queue.last.id);
      final have = _queue.map((e) => e.id).toSet();
      _queue.addAll(more.where((s) => !have.contains(s.id)).take(15));
    } finally {
      _extending = false;
    }
  }

  @override
  Future<void> play() => player.play();

  @override
  Future<void> pause() => player.pause();

  @override
  Future<void> seek(Duration position) => player.seek(position);

  @override
  Future<void> stop() async {
    _token++;
    await player.stop();
    await super.stop();
  }

  @override
  Future<void> skipToNext() async {
    if (_index + 1 >= _queue.length && infinite.value) await _extendQueue();
    if (_index + 1 < _queue.length) {
      await _playIndex(_index + 1);
    } else {
      await player.pause();
      await player.seek(Duration.zero);
    }
  }

  @override
  Future<void> skipToPrevious() async {
    if (player.position > const Duration(seconds: 4) || _index <= 0) {
      await player.seek(Duration.zero);
    } else {
      await _playIndex(_index - 1);
    }
  }
}
