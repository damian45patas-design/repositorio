import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:just_audio_media_kit/just_audio_media_kit.dart';
import 'globals.dart';
import 'handler.dart';
import 'library.dart';
import 'screens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux) JustAudioMediaKit.ensureInitialized();

  lib = Library();
  await lib.load();

  if (Platform.isAndroid || Platform.isIOS || Platform.isMacOS) {
    audio = await AudioService.init(
      builder: () => MusicHandler(lib),
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'com.example.ytm.audio',
        androidNotificationChannelName: 'Reproducción',
        androidNotificationOngoing: true,
      ),
    );
  } else {
    audio = MusicHandler(lib);
  }
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'YTM Client',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFFF4E6B),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF0E0E12),
        ),
        home: const Shell(),
      );
}
