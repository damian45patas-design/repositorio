import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'globals.dart';
import 'models.dart';
import 'yt.dart';

// ======================= Estructura adaptable (móvil / PC) =======================

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    toast.addListener(_onToast);
  }

  void _onToast() {
    final m = toast.value;
    if (m != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }
  }

  @override
  void dispose() {
    toast.removeListener(_onToast);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final items = <(String, IconData, Widget)>[
      ('Inicio', Icons.home_rounded, const HomePage()),
      ('Buscar', Icons.search_rounded, const SearchPage()),
      ('Playlists', Icons.library_music_rounded, const PlaylistsPage()),
      ('Descargas', Icons.download_done_rounded, const DownloadsPage()),
      if (Platform.isAndroid) ('EQ', Icons.equalizer_rounded, const EqPage()),
    ];
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 720; // PC / tablet: barra lateral
      return Scaffold(
        body: SafeArea(
          bottom: false,
          child: Column(children: [
            Expanded(
              child: Row(children: [
                if (wide)
                  NavigationRail(
                    selectedIndex: tab,
                    onDestinationSelected: (i) => setState(() => tab = i),
                    labelType: NavigationRailLabelType.all,
                    destinations: [
                      for (final it in items)
                        NavigationRailDestination(icon: Icon(it.$2), label: Text(it.$1)),
                    ],
                  ),
                Expanded(
                  child: IndexedStack(index: tab, children: [for (final it in items) it.$3]),
                ),
              ]),
            ),
            const PlayerBar(),
          ]),
        ),
        bottomNavigationBar: wide
            ? null
            : NavigationBar(
                selectedIndex: tab,
                onDestinationSelected: (i) => setState(() => tab = i),
                destinations: [
                  for (final it in items) NavigationDestination(icon: Icon(it.$2), label: it.$1),
                ],
              ),
      );
    });
  }
}

// ======================= Reproductor =======================

class PlayerBar extends StatelessWidget {
  const PlayerBar({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Song?>(
      valueListenable: audio.currentSong,
      builder: (context, s, _) {
        if (s == null) return const SizedBox.shrink();
        final cs = Theme.of(context).colorScheme;
        return Material(
          color: cs.surfaceContainerHigh,
          elevation: 8,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            StreamBuilder<Duration?>(
              stream: audio.player.durationStream,
              builder: (_, d) => StreamBuilder<Duration>(
                stream: audio.player.positionStream,
                builder: (_, p) {
                  final maxMs = math.max((d.data ?? Duration.zero).inMilliseconds, 1).toDouble();
                  final v = (p.data ?? Duration.zero).inMilliseconds.toDouble().clamp(0.0, maxMs);
                  return SizedBox(
                    height: 24,
                    child: Slider(
                      value: v.toDouble(),
                      max: maxMs,
                      onChanged: (x) => audio.seek(Duration(milliseconds: x.toInt())),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 8, 8),
              child: Row(children: [
                Thumb(s.thumb, 44),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text(s.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall),
                  ]),
                ),
                ValueListenableBuilder<bool>(
                  valueListenable: audio.infinite,
                  builder: (_, on, __) => IconButton(
                    tooltip: 'Reproducción infinita',
                    icon: Icon(Icons.all_inclusive_rounded, color: on ? cs.primary : null),
                    onPressed: () => audio.infinite.value = !on,
                  ),
                ),
                IconButton(icon: const Icon(Icons.skip_previous_rounded), onPressed: audio.skipToPrevious),
                StreamBuilder<PlayerState>(
                  stream: audio.player.playerStateStream,
                  builder: (_, st) {
                    final state = st.data;
                    final loading = state?.processingState == ProcessingState.loading ||
                        state?.processingState == ProcessingState.buffering;
                    if (loading) {
                      return const Padding(
                        padding: EdgeInsets.all(12),
                        child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
                      );
                    }
                    final playing = state?.playing ?? false;
                    return IconButton.filled(
                      icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
                      onPressed: playing ? audio.pause : audio.play,
                    );
                  },
                ),
                IconButton(icon: const Icon(Icons.skip_next_rounded), onPressed: audio.skipToNext),
              ]),
            ),
          ]),
        );
      },
    );
  }
}

class Thumb extends StatelessWidget {
  final String url;
  final double size;
  const Thumb(this.url, this.size, {super.key});

  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: url.isEmpty
            ? Container(width: size, height: size, color: Colors.white12,
                child: const Icon(Icons.music_note))
            : Image.network(url, width: size, height: size, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(width: size, height: size, color: Colors.white12,
                    child: const Icon(Icons.music_note))),
      );
}

// ======================= Fila de canción con menú =======================

class SongTile extends StatelessWidget {
  final Song song;
  final VoidCallback onTap;
  final VoidCallback? onRemove;
  const SongTile({super.key, required this.song, required this.onTap, this.onRemove});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: lib,
      builder: (context, _) {
        final done = lib.isDownloaded(song.id);
        final prog = lib.progress[song.id];
        return ListTile(
          leading: Thumb(song.thumb, 52),
          title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(song.artist, maxLines: 1, overflow: TextOverflow.ellipsis),
          onTap: onTap,
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            if (prog != null)
              SizedBox(
                width: 22, height: 22,
                child: CircularProgressIndicator(value: prog > 0 ? prog : null, strokeWidth: 2),
              )
            else if (done)
              Icon(Icons.download_done_rounded, color: Theme.of(context).colorScheme.primary),
            PopupMenuButton<String>(
              onSelected: (v) => _menu(context, v),
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'pl', child: Text('Añadir a playlist')),
                const PopupMenuItem(value: 'q', child: Text('Añadir a la cola')),
                if (!done) const PopupMenuItem(value: 'dl', child: Text('Descargar')),
                if (done) const PopupMenuItem(value: 'rm', child: Text('Eliminar descarga')),
                if (onRemove != null) const PopupMenuItem(value: 'out', child: Text('Quitar de la playlist')),
              ],
            ),
          ]),
        );
      },
    );
  }

  void _menu(BuildContext context, String v) {
    switch (v) {
      case 'pl':
        addToPlaylistSheet(context, song);
      case 'q':
        audio.enqueue(song);
      case 'dl':
        lib.download(song);
      case 'rm':
        lib.deleteDownload(song);
      case 'out':
        onRemove?.call();
    }
  }
}

Future<String?> askName(BuildContext context, String title) {
  final c = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true,
          decoration: const InputDecoration(hintText: 'Nombre'),
          onSubmitted: (v) => Navigator.pop(ctx, v.trim())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Crear')),
      ],
    ),
  ).then((v) => (v == null || v.isEmpty) ? null : v);
}

Future<void> addToPlaylistSheet(BuildContext context, Song s) {
  return showModalBottomSheet(
    context: context,
    builder: (ctx) => ListenableBuilder(
      listenable: lib,
      builder: (_, __) => ListView(shrinkWrap: true, children: [
        ListTile(
          leading: const Icon(Icons.add),
          title: const Text('Nueva playlist'),
          onTap: () async {
            final n = await askName(ctx, 'Nueva playlist');
            if (n != null) lib.addToPlaylist(lib.createPlaylist(n), s);
            if (ctx.mounted) Navigator.pop(ctx);
          },
        ),
        for (final p in lib.playlists)
          ListTile(
            leading: const Icon(Icons.queue_music),
            title: Text(p.name),
            subtitle: Text('${p.songs.length} canciones'),
            onTap: () {
              lib.addToPlaylist(p, s);
              Navigator.pop(ctx);
            },
          ),
      ]),
    ),
  );
}

// ======================= Páginas =======================

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<Song>> recs = Yt.recommend(lib.history);

  void _refresh() => setState(() => recs = Yt.recommend(lib.history));

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 8, 8),
        child: Row(children: [
          Text('Para ti', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const Spacer(),
          IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded)),
        ]),
      ),
      Expanded(
        child: FutureBuilder<List<Song>>(
          future: recs,
          builder: (_, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final list = snap.data ?? [];
            if (list.isEmpty) return const Center(child: Text('Sin resultados. Revisa tu conexión.'));
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (_, i) => SongTile(song: list[i], onTap: () => audio.playQueue(list, i)),
            );
          },
        ),
      ),
    ]);
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final c = TextEditingController();
  List<Song> results = [];
  bool loading = false;

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) return;
    setState(() => loading = true);
    try {
      results = await Yt.search(q);
    } catch (_) {
      showToast('Error al buscar');
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: c,
          textInputAction: TextInputAction.search,
          onSubmitted: _search,
          decoration: InputDecoration(
            hintText: 'Buscar canciones, artistas…',
            prefixIcon: const Icon(Icons.search_rounded),
            filled: true,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
          ),
        ),
      ),
      if (loading) const LinearProgressIndicator(),
      Expanded(
        child: ListView.builder(
          itemCount: results.length,
          itemBuilder: (_, i) => SongTile(song: results[i], onTap: () => audio.playQueue(results, i)),
        ),
      ),
    ]);
  }
}

class PlaylistsPage extends StatelessWidget {
  const PlaylistsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: lib,
      builder: (context, _) => Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: const Text('Nueva'),
          onPressed: () async {
            final n = await askName(context, 'Nueva playlist');
            if (n != null) lib.createPlaylist(n);
          },
        ),
        body: lib.playlists.isEmpty
            ? const Center(child: Text('Aún no tienes playlists.\nCrea una o agrega canciones desde el menú ⋮'))
            : ListView(children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('Tus playlists',
                      style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                ),
                for (final p in lib.playlists)
                  ListTile(
                    leading: const Icon(Icons.queue_music_rounded, size: 32),
                    title: Text(p.name),
                    subtitle: Text('${p.songs.length} canciones · ${lib.downloadedCount(p)} offline'),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlaylistDetail(p))),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => lib.deletePlaylist(p),
                    ),
                  ),
              ]),
      ),
    );
  }
}

class PlaylistDetail extends StatelessWidget {
  final UserPlaylist p;
  const PlaylistDetail(this.p, {super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: lib,
      builder: (context, _) {
        final busy = lib.downloadingPlaylists.contains(p.name);
        return Scaffold(
          appBar: AppBar(
            title: Text(p.name),
            actions: [
              IconButton(
                tooltip: 'Reproducir',
                icon: const Icon(Icons.play_arrow_rounded),
                onPressed: p.songs.isEmpty ? null : () => audio.playQueue(p.songs, 0),
              ),
              busy
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)))
                  : IconButton(
                      tooltip: 'Descargar toda la playlist',
                      icon: const Icon(Icons.download_rounded),
                      onPressed: p.songs.isEmpty ? null : () => lib.downloadPlaylist(p),
                    ),
            ],
          ),
          body: p.songs.isEmpty
              ? const Center(child: Text('Playlist vacía'))
              : ListView.builder(
                  itemCount: p.songs.length,
                  itemBuilder: (_, i) => SongTile(
                    song: p.songs[i],
                    onTap: () => audio.playQueue(p.songs, i),
                    onRemove: () => lib.removeFromPlaylist(p, p.songs[i]),
                  ),
                ),
        );
      },
    );
  }
}

class DownloadsPage extends StatelessWidget {
  const DownloadsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: lib,
      builder: (context, _) {
        final list = lib.downloads.where((s) => lib.isDownloaded(s.id)).toList();
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Descargas',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            child: list.isEmpty
                ? const Center(child: Text('Nada descargado todavía'))
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (_, i) => SongTile(song: list[i], onTap: () => audio.playQueue(list, i)),
                  ),
          ),
        ]);
      },
    );
  }
}

/// Ecualizador (solo Android; en PC no hay ecualizador con este motor de audio).
class EqPage extends StatelessWidget {
  const EqPage({super.key});

  @override
  Widget build(BuildContext context) {
    final eq = audio.eq!;
    return ValueListenableBuilder<Song?>(
      valueListenable: audio.currentSong,
      builder: (context, s, _) {
        if (s == null) return const Center(child: Text('Reproduce una canción para usar el ecualizador'));
        return FutureBuilder<AndroidEqualizerParameters>(
          future: eq.parameters,
          builder: (context, snap) {
            final p = snap.data;
            if (p == null) return const Center(child: CircularProgressIndicator());
            return ListView(padding: const EdgeInsets.all(16), children: [
              Text('Ecualizador',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
              StreamBuilder<bool>(
                stream: eq.enabledStream,
                builder: (_, e) => SwitchListTile(
                  title: const Text('Activado'),
                  value: e.data ?? true,
                  onChanged: eq.setEnabled,
                ),
              ),
              for (final band in p.bands) ...[
                Text('${band.centerFrequency.round()} Hz'),
                StreamBuilder<double>(
                  stream: band.gainStream,
                  builder: (_, g) => Slider(
                    min: p.minDecibels,
                    max: p.maxDecibels,
                    value: (g.data ?? band.gain).clamp(p.minDecibels, p.maxDecibels).toDouble(),
                    onChanged: band.setGain,
                  ),
                ),
              ],
            ]);
          },
        );
      },
    );
  }
}
