import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'models.dart';

/// Acceso a YouTube (búsqueda, streams de audio, relacionados y recomendaciones).
class Yt {
  static final yt = YoutubeExplode();
  static final _urlCache = <String, (DateTime, Uri)>{};

  // YouTube cambia seguido: probamos varios "clientes" hasta que uno devuelva audio.
  static final _attempts = <List<YoutubeApiClient>?>[
    null,
    [YoutubeApiClient.androidVr],
    [YoutubeApiClient.safari, YoutubeApiClient.androidVr],
  ];

  static Song fromVideo(Video v) => Song(v.id.value, v.title, v.author, v.thumbnails.mediumResUrl);

  static Future<List<Song>> search(String q) async {
    final r = await yt.search.search(q);
    return r.map(fromVideo).toList();
  }

  static Future<AudioOnlyStreamInfo> bestAudio(String id) async {
    Object? err;
    for (final c in _attempts) {
      try {
        final m = c == null
            ? await yt.videos.streams.getManifest(id)
            : await yt.videos.streams.getManifest(id, ytClients: c);
        if (m.audioOnly.isNotEmpty) return m.audioOnly.withHighestBitrate();
      } catch (e) {
        err = e;
      }
    }
    throw err ?? Exception('Sin audio disponible');
  }

  static Future<Uri> audioUrl(String id) async {
    final c = _urlCache[id];
    if (c != null && DateTime.now().difference(c.$1).inMinutes < 90) return c.$2;
    final info = await bestAudio(id);
    _urlCache[id] = (DateTime.now(), info.url);
    return info.url;
  }

  /// "Radio": canciones relacionadas a una canción.
  static Future<List<Song>> related(String id) async {
    try {
      final v = await yt.videos.get(id);
      final rel = await yt.videos.getRelatedVideos(v);
      final list = rel?.map(fromVideo).toList() ?? <Song>[];
      if (list.isNotEmpty) return list;
      final alt = await search(v.author);
      return alt.where((s) => s.id != id).toList();
    } catch (_) {
      return [];
    }
  }

  /// Recomendaciones personalizadas: lo relacionado a lo que más escuchaste, por frecuencia.
  static Future<List<Song>> recommend(List<Song> history) async {
    if (history.isEmpty) return search('música popular éxitos');
    final seen = history.map((s) => s.id).toSet();
    final lists = await Future.wait(history.take(6).map((h) => related(h.id)));
    final count = <String, int>{};
    final byId = <String, Song>{};
    for (final l in lists) {
      for (final s in l) {
        if (seen.contains(s.id)) continue;
        count[s.id] = (count[s.id] ?? 0) + 1;
        byId[s.id] = s;
      }
    }
    final ids = count.keys.toList()..sort((a, b) => count[b]!.compareTo(count[a]!));
    final out = ids.take(30).map((i) => byId[i]!).toList();
    return out.isEmpty ? search('música popular éxitos') : out;
  }
}
