class Song {
  final String id, title, artist, thumb;
  const Song(this.id, this.title, this.artist, this.thumb);

  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'artist': artist, 'thumb': thumb};

  factory Song.fromJson(Map<String, dynamic> j) =>
      Song(j['id'] as String, j['title'] as String, j['artist'] as String, (j['thumb'] as String?) ?? '');

  @override
  bool operator ==(Object other) => other is Song && other.id == id;
  @override
  int get hashCode => id.hashCode;
}

class UserPlaylist {
  String name;
  final List<Song> songs;
  UserPlaylist(this.name, [List<Song>? songs]) : songs = songs ?? [];

  Map<String, dynamic> toJson() => {'name': name, 'songs': songs.map((s) => s.toJson()).toList()};

  factory UserPlaylist.fromJson(Map<String, dynamic> j) => UserPlaylist(
        j['name'] as String,
        ((j['songs'] as List?) ?? [])
            .map((e) => Song.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}
